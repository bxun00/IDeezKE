import * as functions from "firebase-functions";
import * as admin from "firebase-admin";
admin.initializeApp();

const db = admin.firestore();

export const notifyOnStatusChange = functions.firestore
  .document("business_submissions/{submissionId}")
  .onUpdate(async (change, context) => {
    const beforeStatus = change.before.data().status;
    const afterStatus = change.after.data().status;

    if (beforeStatus !== afterStatus) {
      const ownerId = change.after.data().ownerId;

      await db.collection("notifications").add({
        userId: ownerId,
        title: "Business Submission Update",
        body: \`Your submission is now: \${afterStatus}\`,
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      });
    }
  });

export const verifyUser = functions.https.onCall(async (data, context) => {
  if (!context.auth?.token.admin) {
    throw new functions.https.HttpsError(
      "permission-denied",
      "Only admins can verify users."
    );
  }

  const userId = data.userId;
  await db.collection("users").doc(userId).update({ verified: true });
  return { message: "User marked as verified." };
});
